<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pick n Pay - Home</title>
  <link rel="stylesheet" href="css/style.css">

<style>
    h2 { color: #333; text-align: center; }
    p { font-size: 18px; color: #444; }
  </style>
</head>
<body>
  <header>
    <h1>Pick n Pay Dairy</h1>
    <nav>
      <a href="index.html">Home</a>
      <a href="about.html">About Us</a>
      <a href="production.html">Production</a>
      <a href="products.html">Products</a>
      <a href="contact.html">Contact</a>
    </nav>
  </header>

  <main>
    <h2>Welcome to Pick n Pay Dairy</h2>
    <p>Delivering fresh, high-quality milk and dairy products from farm to fridge.</p>
  </main>

  <footer>
    <p>&copy; 2025 Pick n Pay Dairy</p>
  </footer>
</body>
</html>